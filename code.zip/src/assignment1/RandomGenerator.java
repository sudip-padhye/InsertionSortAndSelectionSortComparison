package assignment1;

import java.util.Random;

public class RandomGenerator {

	public Integer[] generate(int n, int arraySize) {
		Integer[] num = new Integer[arraySize]; // creates array of size arraySize
		Random rand = new Random();

		for (int i = 0; i < arraySize; i++)
			num[i] = rand.nextInt(n); // Generates random number in the range 0 to n-1

		return num;
	}
}
