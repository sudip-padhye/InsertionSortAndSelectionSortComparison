package assignment1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class InputOutputFileWriter {

	public void write(String path, Integer[] array) {
		String text = "";

		BufferedWriter writerInput = null;
		try {
			writerInput = new BufferedWriter(new FileWriter(path)); // Creates file at the specified path
		} catch (IOException e) {
			e.printStackTrace();
		}

		for (int i = 0; i < array.length; i++) { // stores text as comma-separated values
			if (i != array.length - 1)
				text = text + array[i] + ", ";
			else
				text = text + array[i];
		}

		try {
			writerInput.write(text);	// writes the data to file
			writerInput.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
