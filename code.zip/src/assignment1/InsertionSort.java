package assignment1;

public class InsertionSort {

	public void sort(Integer[] num) {
		int size = num.length;

		for (int j = 1; j < size; j++) {
			int key = num[j];
			int i = j - 1;
			while (i >= 0 && num[i] > key) {
				num[i + 1] = num[i];
				i = i - 1;
			}
			num[i + 1] = key;
		}
	}
}
