package assignment1;

public class SelectionSort {

	public void sort(Integer[] num) {
		int index = 0;

		while (index < num.length - 1) {
			int minIndex = smallest(num, index); // returns index of minimum no. beginning from index to length-1
			num = swap(num, index, minIndex); // swaps the no. at index position with the no. at minIndex position
			index++;
		}
	}

	private int smallest(Integer[] num, int start) {
		int minIndex = start;
		for (int i = start; i < num.length; i++) {
			if (num[i] < num[minIndex])
				minIndex = i;
		}
		return minIndex;
	}

	private Integer[] swap(Integer[] num, int index, int minIndex) {
		int temp = num[index];
		num[index] = num[minIndex];
		num[minIndex] = temp;
		return num;
	}

}
