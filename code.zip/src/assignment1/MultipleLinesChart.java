package assignment1;

/* 
 * Citation: This code has been derived using free Java Graph plotting library jfreechart.jar. 
 * This code is taken from the website 
 * (https://steemit.com/visualization/@datatreemap/visualize-a-multiple-lines-graph-with-jfreechart-in-java). 
 */

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.*;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class MultipleLinesChart extends JFrame {

	private static final long serialVersionUID = 1L;

	public MultipleLinesChart(int[] timeInsertion, int[] timeSelection, String title) { // the constructor will contain
																						// the panel of a certain size
																						// and the close operations
		super("Plot"); // calls the super class constructor

		JPanel chartPanel = createChartPanel(timeInsertion, timeSelection, title);
		add(chartPanel, BorderLayout.CENTER);

		setSize(640, 480);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
	}

	private JPanel createChartPanel(int[] timeInsertion, int[] timeSelection, String title) { // this method will create
																								// the chart panel
																								// containing the graph
		String chartTitle = title;
		String xAxisLabel = "Input Size"; // sets label for x-axis
		String yAxisLabel = "Execution Time (milliseconds)"; // sets label for y-axis

		XYDataset dataset = createDataset(timeInsertion, timeSelection);

		JFreeChart chart = ChartFactory.createXYLineChart(chartTitle, xAxisLabel, yAxisLabel, dataset);

		customizeChart(chart);

		return new ChartPanel(chart);
	}

	private XYDataset createDataset(int[] timeInsertion, int[] timeSelection) { // this method creates the data as time
																				// seris
		XYSeriesCollection dataset = new XYSeriesCollection();
		XYSeries series1 = new XYSeries("Insertion Sort");
		XYSeries series2 = new XYSeries("Selection Sort");

		for (int i = 1; i <= 6; i++) // adds individual x value and corresponding y-value for plotting insertion sort
										// line chart
			series1.add(i * 5000, timeInsertion[i - 1]);

		for (int i = 1; i <= 6; i++) // adds individual x value and corresponding y-value for plotting selection sort
										// line chart
			series2.add(i * 5000, timeSelection[i - 1]);

		dataset.addSeries(series1);
		dataset.addSeries(series2);

		return dataset;
	}

	private void customizeChart(JFreeChart chart) { // here we make some customization
		XYPlot plot = chart.getXYPlot();
		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

		// sets paint color for each series
		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesPaint(1, Color.GREEN);

		// sets thickness for series (using strokes)
		renderer.setSeriesStroke(0, new BasicStroke(4.0f));
		renderer.setSeriesStroke(1, new BasicStroke(3.0f));

		// sets paint color for plot outlines
		plot.setOutlinePaint(Color.BLUE);
		plot.setOutlineStroke(new BasicStroke(2.0f));

		// sets renderer for lines
		plot.setRenderer(renderer);

		// sets plot background
		plot.setBackgroundPaint(Color.DARK_GRAY);

		// sets paint color for the grid lines
		plot.setRangeGridlinesVisible(true);
		plot.setRangeGridlinePaint(Color.BLACK);

		plot.setDomainGridlinesVisible(true);
		plot.setDomainGridlinePaint(Color.BLACK);

	}
}
