package assignment1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

import javax.swing.SwingUtilities;

/*
 * The main function that begins the execution of the program
 */

public class Driver {

	public static void main(String[] args) {

		String text = "";
		int[] timeInsertion = new int[6]; // Array to store execution time of Insertion Sort
		int[] timeSelection = new int[6]; // Array to store execution time of Selection Sort
		InputOutputFileWriter ioFile = new InputOutputFileWriter(); // Object initialized to write input & output to
																	// file
		BufferedWriter writer = null;
		String filepath = "C:\\Users\\sudip\\Desktop\\assignment1\\"; // Path to store input & output files
		try {
			writer = new BufferedWriter(new FileWriter(filepath + "result.txt")); // Creates result file to store
																					// execution time
		} catch (IOException e) {
			e.printStackTrace();
		}

		// Input/Plot 1: Large random inputs
		text = text + "Input/Plot 1: Large random inputs\n" + "==================================\n";
		int index = 0;

		for (int size = 5000; size <= 30000; size = size + 5000) {
			long startTime = 0, endTime = 0, durationInsertion = 0, durationSelection = 0;
			Integer[] num = new Integer[size];
			Integer[] numCopy = new Integer[size];

			RandomGenerator randGen = new RandomGenerator();

			for (int run = 1; run <= 3; run++) { // Runs for 3 times to take Average
				num = randGen.generate(size, size);
				ioFile.write(filepath + "InputFiles\\InputPlot1_" + size + ".txt", num); // Writing generated random
																							// numbers to input file
				numCopy = num;

				// Insertion Sort Invocation
				InsertionSort iSort = new InsertionSort();
				startTime = System.currentTimeMillis();
				iSort.sort(num);
				endTime = System.currentTimeMillis();
				durationInsertion = durationInsertion + (endTime - startTime); // Total execution time in milli seconds

				// Selection Sort Invocation
				SelectionSort sSort = new SelectionSort();
				startTime = System.currentTimeMillis();
				sSort.sort(numCopy);
				endTime = System.currentTimeMillis();
				durationSelection = durationSelection + (endTime - startTime); // Total execution time in milli seconds
			}

			ioFile.write(filepath + "OutputFiles\\InputPlot1_" + size + ".txt", num); // Writing sorted numbers to
																						// output file

			timeInsertion[index] = (int) (durationInsertion / 3); // calculates average of 3 runs
			timeSelection[index++] = (int) (durationSelection / 3); // calculates average of 3 runs

			text = text + "Insertion Sort: Input Size=" + size + " AvgExecutionTime=" + durationInsertion / 3
					+ " milliseconds\n" + "Selection Sort: Input Size=" + size + " AvgExecutionTime="
					+ durationSelection / 3 + " milliseconds\n\n";
		}

		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new MultipleLinesChart(timeInsertion, timeSelection, "Input/Plot 1: Large random inputs")
						.setVisible(true);
			}
		});

		// Input/Plot 2: Non-decreasing inputs
		text = text + "\nInput/Plot 2: Non-decreasing inputs\n" + "==================================\n";
		index = 0;
		for (int size = 5000; size <= 30000; size = size + 5000) {
			long startTime = 0, endTime = 0, durationInsertion = 0, durationSelection = 0;
			Integer[] num = new Integer[size];
			Integer[] numCopy = new Integer[size];

			RandomGenerator randGen = new RandomGenerator();

			num = randGen.generate(size, size);
			Arrays.sort(num); // Sorting the input array in non-decreasing order
			ioFile.write(filepath + "InputFiles\\InputPlot2_" + size + ".txt", num); // Writing generated random numbers
																						// to input file
			numCopy = num;

			// Insertion Sort Invocation
			InsertionSort iSort = new InsertionSort();
			startTime = System.currentTimeMillis();
			iSort.sort(num);
			endTime = System.currentTimeMillis();
			durationInsertion = endTime - startTime; // Total execution time in milli seconds

			// Selection Sort Invocation
			SelectionSort sSort = new SelectionSort();
			startTime = System.currentTimeMillis();
			sSort.sort(numCopy);
			endTime = System.currentTimeMillis();
			durationSelection = endTime - startTime; // Total execution time in milli seconds

			ioFile.write(filepath + "OutputFiles\\InputPlot2_" + size + ".txt", num); // Writing sorted numbers to
																						// output file

			timeInsertion[index] = (int) (durationInsertion);
			timeSelection[index++] = (int) (durationSelection);

			text = text + "Insertion Sort: Input Size=" + size + " ExecutionTime=" + durationInsertion
					+ " milliseconds\n" + "Selection Sort: Input Size=" + size + " ExecutionTime=" + durationSelection
					+ " milliseconds\n\n";
		}

		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new MultipleLinesChart(timeInsertion, timeSelection, "Input/Plot 2: Non-decreasing inputs")
						.setVisible(true);
			}
		});

		// Input/Plot 3: Non-increasing inputs
		text = text + "\nInput/Plot 3: Non-increasing inputs\n" + "==================================\n";
		index = 0;
		for (int size = 5000; size <= 30000; size = size + 5000) {
			long startTime = 0, endTime = 0, durationInsertion = 0, durationSelection = 0;
			Integer[] num = new Integer[size];
			Integer[] numCopy = new Integer[size];

			RandomGenerator randGen = new RandomGenerator();

			num = randGen.generate(size, size);
			Arrays.sort(num, Collections.reverseOrder()); // Sorting the input array in non-increasing order
			ioFile.write(filepath + "InputFiles\\InputPlot3_" + size + ".txt", num); // Writing generated random numbers
																						// to input file
			numCopy = num;

			// Insertion Sort Invocation
			InsertionSort iSort = new InsertionSort();
			startTime = System.currentTimeMillis();
			iSort.sort(num);
			endTime = System.currentTimeMillis();
			durationInsertion = endTime - startTime; // Total execution time in milli seconds

			// Selection Sort Invocation
			SelectionSort sSort = new SelectionSort();
			startTime = System.currentTimeMillis();
			sSort.sort(numCopy);
			endTime = System.currentTimeMillis();
			durationSelection = endTime - startTime; // Total execution time in milli seconds

			ioFile.write(filepath + "OutputFiles\\InputPlot3_" + size + ".txt", num); // Writing sorted numbers to
																						// output file

			timeInsertion[index] = (int) (durationInsertion);
			timeSelection[index++] = (int) (durationSelection);

			text = text + "Insertion Sort: Input Size=" + size + " ExecutionTime=" + durationInsertion
					+ " milliseconds\n" + "Selection Sort: Input Size=" + size + " ExecutionTime=" + durationSelection
					+ " milliseconds\n\n";
		}

		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new MultipleLinesChart(timeInsertion, timeSelection, "Input/Plot 3: Non-increasing inputs")
						.setVisible(true);
			}
		});

		// Input/Plot 4: Noisy non-decreasing inputs
		text = text + "\nInput/Plot 4: Noisy non-decreasing inputs\n" + "==================================\n";
		index = 0;
		for (int size = 5000; size <= 30000; size = size + 5000) {
			long startTime = 0, endTime = 0, durationInsertion = 0, durationSelection = 0;
			Integer[] num = new Integer[size];
			Integer[] numCopy = new Integer[size];

			RandomGenerator randGen = new RandomGenerator();

			for (int run = 1; run <= 3; run++) {

				num = randGen.generate(size, size);
				Arrays.sort(num); // Sorting the input array in non-decreasing order

				for (int swaps = 0; swaps < 50; swaps++) {
					Random rand = new Random();
					int i = rand.nextInt(size);
					int j = rand.nextInt(size);
					int temp = num[i];
					num[i] = num[j];
					num[j] = temp;
				}

				ioFile.write(filepath + "InputFiles\\InputPlot4_" + size + ".txt", num); // Writing generated random
																							// numbers
																							// to input file
				numCopy = num;

				// Insertion Sort Invocation
				InsertionSort iSort = new InsertionSort();
				startTime = System.currentTimeMillis();
				iSort.sort(num);
				endTime = System.currentTimeMillis();
				durationInsertion = durationInsertion + (endTime - startTime); // Total execution time in milli seconds

				// Selection Sort Invocation
				SelectionSort sSort = new SelectionSort();
				startTime = System.currentTimeMillis();
				sSort.sort(numCopy);
				endTime = System.currentTimeMillis();
				durationSelection = durationSelection + (endTime - startTime); // Total execution time in milli seconds

				ioFile.write(filepath + "OutputFiles\\InputPlot4_" + size + ".txt", num); // Writing sorted numbers to
																							// output file
			}

			timeInsertion[index] = (int) (durationInsertion / 3);
			timeSelection[index++] = (int) (durationSelection / 3);

			text = text + "Insertion Sort: Input Size=" + size + " ExecutionTime=" + durationInsertion / 3
					+ " milliseconds\n" + "Selection Sort: Input Size=" + size + " ExecutionTime="
					+ durationSelection / 3 + " milliseconds\n\n";
		}

		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new MultipleLinesChart(timeInsertion, timeSelection, "Input/Plot 4: Noisy non-decreasing inputs")
						.setVisible(true);
			}
		});

		// Input/Plot 5: Small random inputs
		text = text + "\nInput/Plot 5: Small random inputs\n" + "==================================\n";
		index = 0;
		int size = 100000, n = 50;
		long startTime = 0, endTime = 0, durationInsertion = 0, durationSelection = 0;
		Integer[] num = new Integer[size];
		Integer[] numCopy = new Integer[size];

		RandomGenerator randGen = new RandomGenerator();

		num = randGen.generate(n, size);
		ioFile.write(filepath + "InputFiles\\InputPlot5_" + size + ".txt", num); // Writing generated random
																					// numbers to input file
		numCopy = num;

		// Insertion Sort Invocation
		InsertionSort iSort = new InsertionSort();
		startTime = System.currentTimeMillis();
		iSort.sort(num);
		endTime = System.currentTimeMillis();
		durationInsertion = (endTime - startTime); // Total execution time in milli seconds

		// Selection Sort Invocation
		SelectionSort sSort = new SelectionSort();
		startTime = System.currentTimeMillis();
		sSort.sort(numCopy);
		endTime = System.currentTimeMillis();
		durationSelection = (endTime - startTime); // Total execution time in milli seconds

		ioFile.write(filepath + "OutputFiles\\InputPlot5_" + size + ".txt", num); // Writing sorted numbers to
																					// output file

		timeInsertion[index] = (int) durationInsertion;
		timeSelection[index++] = (int) durationSelection;

		text = text + "Insertion Sort: Input Size=" + size + " ExecutionTime=" + durationInsertion + " milliseconds\n"
				+ "Selection Sort: Input Size=" + size + " ExecutionTime=" + durationSelection + " milliseconds\n\n";

		try {
			writer.write(text);
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
